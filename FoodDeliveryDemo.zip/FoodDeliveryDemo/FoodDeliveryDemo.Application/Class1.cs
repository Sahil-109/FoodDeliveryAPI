﻿namespace FoodDeliveryDemo.Application
{
	public class Class1
	{

	}
}
