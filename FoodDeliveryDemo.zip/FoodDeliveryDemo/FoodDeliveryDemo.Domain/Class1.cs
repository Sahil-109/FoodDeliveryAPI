﻿namespace FoodDeliveryDemo.Domain
{
	public class Class1
	{

	}
}
