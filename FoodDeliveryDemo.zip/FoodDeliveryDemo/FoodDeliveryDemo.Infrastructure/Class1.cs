﻿namespace FoodDeliveryDemo.Infrastructure
{
	public class Class1
	{

	}
}
